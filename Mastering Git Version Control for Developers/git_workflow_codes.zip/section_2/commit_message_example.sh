
# Section 2: How to Write Good Commit Messages

# Example commit message
# Subject line (header)
Fix login button alignment on the homepage

# Body
The login button was misaligned in the homepage layout on smaller screens. This fix adjusts the CSS to ensure the button is centered.

# Footer (optional)
Fixes: #45
