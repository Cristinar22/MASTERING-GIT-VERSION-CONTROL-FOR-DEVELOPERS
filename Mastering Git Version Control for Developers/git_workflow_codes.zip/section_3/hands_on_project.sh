
# Section 3: Hands-On: Adopting a Git Workflow for Team Collaboration

# Step-by-step hands-on project for adopting Git workflow

# Create a GitHub Repository
git clone https://github.com/yourusername/team-collaboration-demo.git
cd team-collaboration-demo

# Create a New Feature Branch
git checkout -b feature/user-profile-page

# Make Changes and Commit
echo "<html><head><title>User Profile</title></head><body><h1>Welcome, User!</h1></body></html>" > user-profile.html
git add user-profile.html
git commit -m "Add user profile page"

# Push Your Feature Branch
git push origin feature/user-profile-page

# Create a Pull Request
# Go to GitHub and create a pull request for review

# Review and Merge the Pull Request
# Once the PR is reviewed and approved, merge it into main
