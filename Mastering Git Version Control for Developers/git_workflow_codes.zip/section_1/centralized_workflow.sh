
# Section 1: Establishing a Team Workflow with Git

# Centralized Workflow
# Simple example of committing to a single main branch
git clone https://github.com/yourusername/project.git
cd project
git checkout -b feature/new-feature
# Add changes and commit
git add .
git commit -m "Add new feature"
git push origin feature/new-feature

# Feature Branch Workflow
# Creating a new feature branch and committing
git checkout -b feature/new-feature
git add .
git commit -m "Add new feature"
git push origin feature/new-feature

# Gitflow Workflow
# Creating a new feature branch from develop
git checkout -b feature/feature-name develop
git push origin feature/feature-name

# Forking Workflow
# Forking the repository on GitHub, then cloning it locally
git clone https://github.com/yourusername/forked-repository.git
cd forked-repository
git checkout -b feature/new-feature
git push origin feature/new-feature
