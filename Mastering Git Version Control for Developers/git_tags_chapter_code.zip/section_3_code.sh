# Section 3: Hands-On: Tagging Your Code for Releases
# Step-by-Step Hands-On Project

# Step 1: Initialize a new Git repository
mkdir my-first-release
cd my-first-release
git init

# Step 2: Create and edit a file
echo "<html><head><title>My First Release</title></head><body><h1>Welcome to my project!</h1></body></html>" > index.html

# Step 3: Commit the file
git add index.html
git commit -m "Initial commit with index.html"

# Step 4: Create an annotated tag for version 1.0.0
git tag -a v1.0.0 -m "First official release"

# Step 5: Push the tag to the remote repository
git remote add origin https://github.com/yourusername/my-first-release.git
git push origin main
git push --tags
