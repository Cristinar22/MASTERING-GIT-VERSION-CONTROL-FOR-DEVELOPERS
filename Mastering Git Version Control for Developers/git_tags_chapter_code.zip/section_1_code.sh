# Section 1: What are Tags in Git?
# Understanding Git Tags

# A tag is a reference that points to a specific commit in your repository’s history.
# Tags are used for marking important points like releases or milestones.
# Types of Tags:
# 1. Lightweight Tags
# 2. Annotated Tags

# Example of creating an annotated tag
git tag -a v1.0.0 -m "First official release"

# Listing all tags
git tag

# Tagging a specific commit
git tag -a v1.0.0 <commit-hash> -m "First official release"
