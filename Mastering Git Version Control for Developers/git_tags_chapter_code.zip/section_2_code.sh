# Section 2: Using Tags for Versioning and Releases
# Tagging for Versioning and Releases

# Creating an annotated tag for a release
git tag -a v1.0.0 -m "First official release"

# Pushing tags to the remote repository
git push origin v1.0.0

# Pushing all tags at once
git push --tags
