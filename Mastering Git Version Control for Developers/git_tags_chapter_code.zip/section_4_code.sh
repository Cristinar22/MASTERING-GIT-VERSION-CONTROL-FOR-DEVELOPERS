# Section 4: Tagging Best Practices
# Best practices for tagging

# Use Semantic Versioning
# Example: v1.0.0, v1.1.0, v2.0.0

# Tag stable versions
# Example: Avoid tagging untested or experimental branches

# Tag early and often
# Example: Tagging after a bug fix, new feature, or milestone

# Use annotated tags for releases
git tag -a v1.0.0 -m "First official release"
