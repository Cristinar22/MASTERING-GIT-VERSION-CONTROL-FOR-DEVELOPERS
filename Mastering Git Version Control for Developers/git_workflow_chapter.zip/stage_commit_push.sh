
            git add index.html
            git commit -m "Initial commit with index.html"
            git remote add origin https://github.com/yourusername/my-git-project.git
            git push -u origin main
            