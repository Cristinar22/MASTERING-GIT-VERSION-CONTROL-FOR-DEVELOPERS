
            mkdir my-git-project
            cd my-git-project
            git init
            