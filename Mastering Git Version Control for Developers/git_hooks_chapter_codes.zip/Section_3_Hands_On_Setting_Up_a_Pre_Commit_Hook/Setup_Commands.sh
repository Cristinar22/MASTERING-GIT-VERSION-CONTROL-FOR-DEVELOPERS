
#!/bin/sh
# Setup commands for initializing Git repository and installing ESLint.
mkdir my-git-hooks-demo
cd my-git-hooks-demo
git init
npm init -y
npm install eslint --save-dev
npx eslint --init
