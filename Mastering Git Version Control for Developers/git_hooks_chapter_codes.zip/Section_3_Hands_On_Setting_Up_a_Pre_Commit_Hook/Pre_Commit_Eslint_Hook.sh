
#!/bin/sh
# Pre-commit hook that runs ESLint check on the code.
echo "Running ESLint..."
npx eslint . --ext .js,.jsx  # Run ESLint on JavaScript files
if [ $? -ne 0 ]; then
  echo "ESLint found issues! Commit aborted."
  exit 1
fi
