
#!/bin/sh
echo "Enabling Git Hook..."
# Command to enable a specific Git hook
chmod +x .git/hooks/pre-commit
