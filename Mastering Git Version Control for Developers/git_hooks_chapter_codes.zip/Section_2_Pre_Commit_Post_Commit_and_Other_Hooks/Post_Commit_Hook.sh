
#!/bin/sh
# Post-commit hook to send a Slack notification.
echo "Sending commit notification to Slack..."
curl -X POST -H 'Content-type: application/json' --data '{"text":"A new commit was made!"}' https://hooks.slack.com/services/YOUR_SLACK_WEBHOOK_URL
