
#!/bin/sh
# Pre-push hook to run tests before pushing to a remote repository.
echo "Running tests before push..."
npm run test  # Run tests before pushing
if [ $? -ne 0 ]; then
  echo "Tests failed! Push aborted."
  exit 1
fi
