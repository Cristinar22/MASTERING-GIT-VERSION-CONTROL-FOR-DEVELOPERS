
#!/bin/sh
# Pre-commit hook that runs a linter before committing code.
echo "Running linter before commit..."
npm run lint  # Run linter
if [ $? -ne 0 ]; then
  echo "Linter found issues! Commit aborted."
  exit 1
fi
