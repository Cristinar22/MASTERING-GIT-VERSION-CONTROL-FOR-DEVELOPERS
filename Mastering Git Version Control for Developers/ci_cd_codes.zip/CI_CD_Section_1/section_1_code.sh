
# Section 1: Integrating Git with CI/CD Tools

# CI/CD Tools Configuration Files
## Jenkins Configuration (Example)

# Jenkinsfile Example
pipeline {
    agent any

    stages {
        stage('Build') {
            steps {
                script {
                    sh 'npm install'
                    sh 'npm test'
                }
            }
        }
        stage('Deploy') {
            steps {
                script {
                    sh 'git push heroku master'
                }
            }
        }
    }
}
