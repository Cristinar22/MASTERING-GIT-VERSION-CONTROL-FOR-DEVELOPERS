
# Section 2: Setting Up CI/CD with Jenkins

# Example Jenkinsfile for Node.js
pipeline {
    agent any

    stages {
        stage('Install Dependencies') {
            steps {
                script {
                    sh 'npm install'
                }
            }
        }
        stage('Run Tests') {
            steps {
                script {
                    sh 'npm test'
                }
            }
        }
        stage('Deploy to Staging') {
            steps {
                script {
                    sh './deploy.sh'
                }
            }
        }
    }
}
