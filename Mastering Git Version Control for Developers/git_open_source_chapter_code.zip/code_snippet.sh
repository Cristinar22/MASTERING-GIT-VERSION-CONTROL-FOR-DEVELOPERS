
git clone https://github.com/your-username/repository-name.git
cd repository-name
git remote add upstream https://github.com/original-owner/repository-name.git
git fetch upstream
git checkout main
git merge upstream/main
git checkout -b feature-branch-name
git add .
git commit -m "Add new feature: [description]"
git push origin feature-branch-name
