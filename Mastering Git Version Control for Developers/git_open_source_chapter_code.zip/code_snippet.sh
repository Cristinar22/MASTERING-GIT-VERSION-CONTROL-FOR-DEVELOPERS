
git clone https://github.com/your-username/project-name.git
cd project-name
git checkout -b feature/fix-bug
git commit -m "Fix issue with login form validation"
git push origin feature/fix-bug
