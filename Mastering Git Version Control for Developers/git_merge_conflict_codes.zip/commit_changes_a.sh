git add index.html
git commit -m "Updated heading in index.html" 