git add index.html
git commit -m "Resolved merge conflict in index.html" 