git checkout branch-a
git merge branch-b