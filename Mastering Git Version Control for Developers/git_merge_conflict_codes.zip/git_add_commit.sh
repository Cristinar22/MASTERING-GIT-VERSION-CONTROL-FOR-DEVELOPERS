git add <file-name>
git commit -m "Resolved merge conflict in <file-name>" 