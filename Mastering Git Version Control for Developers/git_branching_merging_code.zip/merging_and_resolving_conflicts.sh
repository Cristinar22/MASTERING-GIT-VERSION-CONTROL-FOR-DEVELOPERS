
# Section 3: Merging Branches and Resolving Conflicts

# Merging Branches
# Once you're done working on a branch and ready to incorporate your changes back into the main project, you need to merge your branch.

# 1. Switch to the main Branch
git checkout main

# 2. Merge Your Branch
git merge feature-login

# Handling Merge Conflicts
# A merge conflict occurs when two branches have changes in the same part of a file, and Git can’t figure out which version to keep.

# Example Conflict Markers:
# <<<<<<< HEAD
# Your changes in the main branch
# =======
# Changes from the feature branch
# >>>>>>> feature-login
        