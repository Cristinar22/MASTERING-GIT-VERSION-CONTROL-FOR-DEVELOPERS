
# Section 1: What is Branching and Why Use It?

# Understanding Branching
# At the heart of Git’s flexibility is the ability to branch. Branching allows you to work on different parts of your project simultaneously, without affecting the main project. It’s like creating parallel universes for your code, where each branch is a separate line of development.

# When you create a branch, you're essentially creating a snapshot of the project at a certain point in time. You can make changes to this branch without worrying about interfering with the main line of code (usually the main or master branch). Once you're satisfied with the changes, you can merge that branch back into the main project.

# Why Use Branching?
# 1. Work on Features Independently
# Branches allow you to develop new features or fixes without affecting the stability of the main project.

# 2. Experiment Safely
# If you're not sure about an idea, you can experiment in a branch, and if it doesn't work out, you can easily delete the branch without any impact on the main code.

# 3. Collaboration
# Different team members can work on their own branches and later merge their work into the main project, making it easy to collaborate without stepping on each other’s toes.

# Example Command:
# git branch feature-login
        