
# Section 2: Creating and Switching Branches

# How to Create a Branch
# Creating a branch in Git is simple. When you create a branch, Git essentially takes a snapshot of your current project (from the main branch or whichever branch you're on) and makes a new one.

# 1. Creating a New Branch
git branch feature-login

# 2. Switching to a Branch
git checkout feature-login

# To Create and Switch to a Branch in One Command:
git checkout -b feature-login
        