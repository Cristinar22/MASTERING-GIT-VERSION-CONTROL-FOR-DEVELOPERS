
# Section 4: Hands-On: Branching and Merging in Practice

# 1. Initialize Your Project
mkdir my-website
cd my-website
git init

# 2. Create and Switch to the feature-login Branch
git checkout -b feature-login

# 3. Modify a File (e.g., index.html)
echo "<html><body><h1>Welcome to the Website!</h1><p>This is the login page.</p></body></html>" > index.html

# 4. Stage and Commit the Changes
git add index.html
git commit -m "Added basic HTML structure for the login page"

# 5. Switch Back to the main Branch
git checkout main

# 6. Merge the feature-login Branch into main
git merge feature-login

# 7. Handle Merge Conflicts (if any)
# If there are any conflicts, open the conflicting files, resolve the conflicts, and commit the resolved files
git add index.html
git commit -m "Resolved merge conflict in index.html"
        